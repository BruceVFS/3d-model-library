Synthetic demonstration package for the 3D Model Library hosted demo.
